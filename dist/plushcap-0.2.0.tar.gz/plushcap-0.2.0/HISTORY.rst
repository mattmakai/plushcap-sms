.. :changelog:

History
-------

0.2.0 (2014-07-13)
------------------
* Library now sends an SMS alert if a URL returns something other than 200 OK.

0.1.1 (2014-07-07)
---------------------
* Working release that allows contacting a URL.

0.1.0 (2014-07-06)
---------------------
* First release on PyPI.
