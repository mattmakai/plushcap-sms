========
Usage
========

To use Plushcap in a project::

	import plushcap