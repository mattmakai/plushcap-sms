============
Installation
============

At the command line::

    $ easy_install plushcap

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv plushcap
    $ pip install plushcap