.. :changelog:

History
-------

0.1.0 (2014-07-06)
---------------------

* First release on PyPI.